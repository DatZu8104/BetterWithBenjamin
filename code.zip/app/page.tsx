'use client';

import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Flashcard } from '@/components/flashcard';
import { WordForm } from '@/components/word-form';

interface Word {
  id: string;
  english: string;
  definition: string;
}

export default function Home() {
  const [words, setWords] = useState<Word[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showForm, setShowForm] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Load words from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('vocabulary-words');
    if (saved) {
      try {
        setWords(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load saved words:', e);
      }
    }
    setIsLoading(false);
  }, []);

  // Save words to localStorage whenever they change
  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('vocabulary-words', JSON.stringify(words));
    }
  }, [words, isLoading]);

  const addWord = (english: string, definition: string) => {
    const newWord: Word = {
      id: Date.now().toString(),
      english,
      definition,
    };
    setWords([...words, newWord]);
    setShowForm(false);
  };

  const deleteWord = (id: string) => {
    const filtered = words.filter((w) => w.id !== id);
    setWords(filtered);
    if (currentIndex >= filtered.length && currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const nextCard = () => {
    setCurrentIndex((prev) => (prev + 1) % words.length);
  };

  const prevCard = () => {
    setCurrentIndex((prev) => (prev - 1 + words.length) % words.length);
  };

  return (
    <main className="min-h-screen bg-background text-foreground flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-2 text-balance">English Vocabulary</h1>
          <p className="text-muted-foreground text-lg">Master new words with interactive flashcards</p>
        </div>

        {/* Main Content */}
        <div className="flex flex-col gap-8">
          {/* Flashcard Display */}
          {words.length > 0 ? (
            <div className="space-y-6">
              <Flashcard word={words[currentIndex]} />

              {/* Card Counter */}
              <div className="text-center">
                <p className="text-muted-foreground">
                  Card {currentIndex + 1} of {words.length}
                </p>
              </div>

              {/* Navigation */}
              <div className="flex gap-4 justify-center">
                <Button
                  variant="outline"
                  onClick={prevCard}
                  className="px-8"
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  onClick={nextCard}
                  className="px-8"
                >
                  Next
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => deleteWord(words[currentIndex].id)}
                  className="px-8"
                >
                  Delete
                </Button>
              </div>
            </div>
          ) : (
            <Card className="p-12 text-center border-dashed">
              <p className="text-muted-foreground mb-4">No vocabulary words yet. Add your first word to get started!</p>
            </Card>
          )}

          {/* Add Word Section */}
          <div className="border-t border-border pt-8">
            {!showForm ? (
              <Button
                onClick={() => setShowForm(true)}
                className="w-full md:w-auto"
                size="lg"
              >
                Add New Word
              </Button>
            ) : (
              <div className="space-y-4">
                <WordForm onAdd={addWord} onCancel={() => setShowForm(false)} />
              </div>
            )}
          </div>

          {/* Statistics */}
          {words.length > 0 && (
            <div className="text-center text-sm text-muted-foreground">
              Total words learned: <span className="font-semibold text-foreground">{words.length}</span>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
