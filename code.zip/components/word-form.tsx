'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface WordFormProps {
  onAdd: (english: string, definition: string) => void;
  onCancel: () => void;
}

export function WordForm({ onAdd, onCancel }: WordFormProps) {
  const [english, setEnglish] = useState('');
  const [definition, setDefinition] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (english.trim() && definition.trim()) {
      onAdd(english.trim(), definition.trim());
      setEnglish('');
      setDefinition('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <label className="text-sm font-medium">English Word</label>
        <Input
          placeholder="Enter English word"
          value={english}
          onChange={(e) => setEnglish(e.target.value)}
          autoFocus
        />
      </div>
      <div className="space-y-2">
        <label className="text-sm font-medium">Definition</label>
        <Input
          placeholder="Enter definition or translation"
          value={definition}
          onChange={(e) => setDefinition(e.target.value)}
        />
      </div>
      <div className="flex gap-3">
        <Button type="submit" className="flex-1">
          Add Word
        </Button>
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
          Cancel
        </Button>
      </div>
    </form>
  );
}
