'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/card';

interface Word {
  id: string;
  english: string;
  definition: string;
}

interface FlashcardProps {
  word: Word;
}

export function Flashcard({ word }: FlashcardProps) {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div className="perspective">
      <Card
        className="p-12 min-h-80 flex items-center justify-center cursor-pointer transition-all duration-500 hover:shadow-lg"
        onClick={() => setIsFlipped(!isFlipped)}
        style={{
          transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
          transformStyle: 'preserve-3d',
          backfaceVisibility: 'hidden',
        }}
      >
        <div className="text-center space-y-4 w-full">
          {!isFlipped ? (
            <>
              <p className="text-sm text-muted-foreground uppercase tracking-wide">English Word</p>
              <p className="text-5xl font-bold break-words">{word.english}</p>
              <p className="text-xs text-muted-foreground mt-8">Click to reveal definition</p>
            </>
          ) : (
            <>
              <p className="text-sm text-muted-foreground uppercase tracking-wide">Definition</p>
              <p className="text-2xl leading-relaxed break-words">{word.definition}</p>
              <p className="text-xs text-muted-foreground mt-8">Click to reveal word</p>
            </>
          )}
        </div>
      </Card>

      {/* CSS for 3D flip effect */}
      <style jsx>{`
        .perspective {
          perspective: 1000px;
        }
      `}</style>
    </div>
  );
}
